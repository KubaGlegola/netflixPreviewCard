/**
* @type {import('vite').UserConfig}
*/
export default {
    css: {
        devSourcemap: true,
    },
}